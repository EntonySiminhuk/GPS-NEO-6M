#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"

static const char *TAG = "TESTE_ESP32";

void app_main(void)
{
    while (1) {
        ESP_LOGI(TAG, "ESP32 funcionando! LED ligado.");
        vTaskDelay(pdMS_TO_TICKS(1000));

        ESP_LOGI(TAG, "ESP32 funcionando! LED desligado.");
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}